export class Report {
  date_created_from: Date;
  date_created_till: Date;
  type: string = "expense";
  category: string;
}
