export class Transaction {
	_id: string;
	category: string;
	type: string;
	total: number;
	description: string;
	date_created: Date;
}